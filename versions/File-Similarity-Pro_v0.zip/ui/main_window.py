from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QSettings
from PySide6.QtGui import QColor, QPixmap
from utils.worker import ScanWorker
from ui.preview_window import PreviewWindow
import os
import json

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("File Similarity Pro - Fast Duplicate Finder")
        self.resize(1100, 700)
        self.duplicate_groups = []
        self.all_groups = []  # Store all groups for filtering
        self.worker = None
        self.group_counter = 0
        
        # Load settings
        self.settings = QSettings("FileSimilarityPro", "DuplicateFinder")
        self.dark_mode = self.settings.value("dark_mode", False, type=bool)
        self.load_ignored_patterns()
        
        # Create UI
        self.setup_ui()
        self.apply_theme()

    def load_ignored_patterns(self):
        """Load ignored file patterns from settings"""
        default_patterns = [
            "*.tmp",
            "*.cache",
            "*.log",
            ".git/*",
            "__pycache__/*",
            "node_modules/*"
        ]
        patterns_str = self.settings.value("ignored_patterns", json.dumps(default_patterns))
        try:
            self.ignored_patterns = json.loads(patterns_str)
        except:
            self.ignored_patterns = default_patterns

    def save_ignored_patterns(self):
        """Save ignored file patterns to settings"""
        self.settings.setValue("ignored_patterns", json.dumps(self.ignored_patterns))

    def setup_ui(self):
        # Theme toggle button
        self.theme_btn = QPushButton("☀️" if self.dark_mode else "🌙")
        self.theme_btn.clicked.connect(self.toggle_theme)
        self.theme_btn.setFixedWidth(30)

        # Path input
        self.path_input = QLineEdit()
        browse = QPushButton("Browse")
        browse.clicked.connect(self.browse)

        # Scan and Stop buttons
        self.scan_btn = QPushButton("Scan for Duplicates")
        self.scan_btn.clicked.connect(self.start_scan)
        
        self.stop_btn = QPushButton("Stop Scan")
        self.stop_btn.clicked.connect(self.stop_scan)
        self.stop_btn.setEnabled(False)
        
        # Ignore patterns button
        self.ignore_btn = QPushButton("Ignore Patterns")
        self.ignore_btn.clicked.connect(self.show_ignore_dialog)
        self.ignore_btn.setFixedWidth(120)

        # Progress bar
        self.progress = QProgressBar()
        
        # Status label
        self.status_label = QLabel("Ready")
        
        # Results summary
        self.summary_label = QLabel("")
        self.summary_label.setStyleSheet("font-weight: bold;")

        # Filter controls
        filter_group = QGroupBox("Filter Results")
        filter_layout = QHBoxLayout()
        
        # File type filter
        filter_layout.addWidget(QLabel("File Type:"))
        self.type_combo = QComboBox()
        self.type_combo.addItems(["All Files", "Images Only", "Text Only", "Other Files"])
        self.type_combo.currentTextChanged.connect(self.apply_filters)
        filter_layout.addWidget(self.type_combo)
        
        # Similarity filter
        filter_layout.addWidget(QLabel("Min Similarity:"))
        self.similarity_spin = QSpinBox()
        self.similarity_spin.setRange(50, 100)
        self.similarity_spin.setValue(75)
        self.similarity_spin.setSuffix("%")
        self.similarity_spin.valueChanged.connect(self.apply_filters)
        filter_layout.addWidget(self.similarity_spin)
        
        # Min file size filter
        filter_layout.addWidget(QLabel("Min Size:"))
        self.size_spin = QSpinBox()
        self.size_spin.setRange(0, 1000)
        self.size_spin.setValue(0)
        self.size_spin.setSuffix(" KB")
        self.size_spin.valueChanged.connect(self.apply_filters)
        filter_layout.addWidget(self.size_spin)
        
        # Search box
        filter_layout.addWidget(QLabel("Search:"))
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("File name or path...")
        self.search_box.textChanged.connect(self.apply_filters)
        filter_layout.addWidget(self.search_box)
        
        filter_layout.addStretch()
        filter_group.setLayout(filter_layout)

        # Table for results
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Group", "File Path", "Size", "Similarity %"])
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.doubleClicked.connect(self.open_preview)
        
        # Buttons
        self.preview_btn = QPushButton("Preview Group")
        self.preview_btn.clicked.connect(self.preview_selected_group)
        self.preview_btn.setEnabled(False)
        
        self.delete_btn = QPushButton("Delete Selected Files")
        self.delete_btn.clicked.connect(self.delete_selected)
        self.delete_btn.setEnabled(False)

        # Layout
        top = QHBoxLayout()
        top.addWidget(QLabel("Folder:"))
        top.addWidget(self.path_input)
        top.addWidget(browse)
        top.addWidget(self.scan_btn)
        top.addWidget(self.stop_btn)
        top.addWidget(self.ignore_btn)
        top.addWidget(self.theme_btn)

        button_layout = QHBoxLayout()
        button_layout.addWidget(self.preview_btn)
        button_layout.addWidget(self.delete_btn)
        button_layout.addStretch()

        layout = QVBoxLayout()
        layout.addLayout(top)
        layout.addWidget(self.status_label)
        layout.addWidget(self.progress)
        layout.addWidget(self.summary_label)
        layout.addWidget(filter_group)
        layout.addWidget(QLabel("Double-click a row to preview the group"))
        layout.addWidget(self.table)
        layout.addLayout(button_layout)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def show_ignore_dialog(self):
        """Show dialog to configure ignored patterns"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Configure Ignored Patterns")
        dialog.resize(600, 400)
        
        layout = QVBoxLayout()
        
        info_label = QLabel(
            "Enter file patterns to ignore during scanning (one per line).\n"
            "Use * as wildcard. Examples: *.tmp, .git/*, __pycache__/*"
        )
        layout.addWidget(info_label)
        
        # Text editor for patterns
        text_edit = QTextEdit()
        text_edit.setPlainText("\n".join(self.ignored_patterns))
        layout.addWidget(text_edit)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        reset_btn = QPushButton("Reset to Defaults")
        def reset_defaults():
            default = [
                "*.tmp",
                "*.cache",
                "*.log",
                ".git/*",
                "__pycache__/*",
                "node_modules/*"
            ]
            text_edit.setPlainText("\n".join(default))
        reset_btn.clicked.connect(reset_defaults)
        
        save_btn = QPushButton("Save")
        def save_patterns():
            patterns = [p.strip() for p in text_edit.toPlainText().split("\n") if p.strip()]
            self.ignored_patterns = patterns
            self.save_ignored_patterns()
            QMessageBox.information(dialog, "Success", "Ignore patterns saved!")
            dialog.accept()
        save_btn.clicked.connect(save_patterns)
        
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(dialog.reject)
        
        button_layout.addWidget(reset_btn)
        button_layout.addStretch()
        button_layout.addWidget(save_btn)
        button_layout.addWidget(cancel_btn)
        
        layout.addLayout(button_layout)
        dialog.setLayout(layout)
        
        # Apply theme to dialog
        if self.dark_mode:
            dialog.setStyleSheet("""
                QDialog { background-color: #1e1e1e; color: #e0e0e0; }
                QLabel { color: #e0e0e0; }
                QTextEdit { background-color: #2d2d2d; color: #e0e0e0; border: 1px solid #3d3d3d; }
                QPushButton { background-color: #0d7377; color: white; border: none; padding: 8px; border-radius: 4px; }
                QPushButton:hover { background-color: #14a085; }
            """)
        
        dialog.exec()

    def toggle_theme(self):
        self.dark_mode = not self.dark_mode
        self.settings.setValue("dark_mode", self.dark_mode)
        self.apply_theme()
        self.theme_btn.setText("☀️" if self.dark_mode else "🌙")

    def apply_theme(self):
        if self.dark_mode:
            self.setStyleSheet("""
                QMainWindow { background-color: #1e1e1e; }
                QWidget { background-color: #1e1e1e; color: #e0e0e0; }
                QLineEdit { background-color: #2d2d2d; border: 1px solid #3d3d3d; padding: 5px; color: #e0e0e0; border-radius: 3px; }
                QPushButton { background-color: #0d7377; color: white; border: none; padding: 8px; border-radius: 4px; font-weight: bold; }
                QPushButton:hover { background-color: #14a085; }
                QPushButton:pressed { background-color: #0a5f63; }
                QPushButton:disabled { background-color: #3d3d3d; color: #777777; }
                QTableWidget { background-color: #2d2d2d; alternate-background-color: #262626; color: #e0e0e0; gridline-color: #3d3d3d; border: 1px solid #3d3d3d; }
                QTableWidget::item:selected { background-color: #0d7377; color: white; }
                QHeaderView::section { background-color: #262626; color: #e0e0e0; padding: 8px; border: 1px solid #3d3d3d; font-weight: bold; }
                QLabel { color: #e0e0e0; }
                QProgressBar { border: 1px solid #3d3d3d; border-radius: 3px; background-color: #2d2d2d; text-align: center; color: #e0e0e0; }
                QProgressBar::chunk { background-color: #0d7377; }
                QComboBox { background-color: #2d2d2d; color: #e0e0e0; border: 1px solid #3d3d3d; padding: 5px; }
                QComboBox::drop-down { border: none; }
                QComboBox::down-arrow { image: none; border: 2px solid #e0e0e0; width: 6px; height: 6px; }
                QSpinBox { background-color: #2d2d2d; color: #e0e0e0; border: 1px solid #3d3d3d; padding: 5px; }
                QGroupBox { color: #e0e0e0; border: 1px solid #3d3d3d; border-radius: 5px; margin-top: 10px; padding-top: 10px; }
                QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }
            """)
            self.summary_label.setStyleSheet("font-weight: bold; color: #14a085;")
        else:
            self.setStyleSheet("""
                QMainWindow { background-color: #ffffff; }
                QWidget { background-color: #ffffff; color: #333333; }
                QLineEdit { background-color: white; border: 1px solid #cccccc; padding: 5px; color: #333333; border-radius: 3px; }
                QPushButton { background-color: #4a90e2; color: white; border: none; padding: 8px; border-radius: 4px; font-weight: bold; }
                QPushButton:hover { background-color: #3a7bc8; }
                QPushButton:pressed { background-color: #2c6bb6; }
                QPushButton:disabled { background-color: #cccccc; color: #666666; }
                QTableWidget { background-color: white; alternate-background-color: #f9f9f9; color: #333333; gridline-color: #e0e0e0; border: 1px solid #cccccc; }
                QTableWidget::item:selected { background-color: #4a90e2; color: white; }
                QHeaderView::section { background-color: #f0f0f0; color: #333333; padding: 8px; border: 1px solid #cccccc; font-weight: bold; }
                QLabel { color: #333333; }
                QProgressBar { border: 1px solid #cccccc; border-radius: 3px; background-color: #f0f0f0; text-align: center; color: #333333; }
                QProgressBar::chunk { background-color: #4a90e2; }
                QComboBox { background-color: white; color: #333333; border: 1px solid #cccccc; padding: 5px; }
                QSpinBox { background-color: white; color: #333333; border: 1px solid #cccccc; padding: 5px; }
                QGroupBox { color: #333333; border: 1px solid #cccccc; border-radius: 5px; margin-top: 10px; padding-top: 10px; }
                QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }
            """)
            self.summary_label.setStyleSheet("font-weight: bold; color: #0066cc;")

    def browse(self):
        path = QFileDialog.getExistingDirectory(self, "Select Folder")
        if path:
            self.path_input.setText(path)

    def start_scan(self):
        path = self.path_input.text()
        if not path or not os.path.isdir(path):
            QMessageBox.warning(self, "Error", "Please select a valid folder")
            return
            
        self.table.setRowCount(0)
        self.scan_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.delete_btn.setEnabled(False)
        self.preview_btn.setEnabled(False)
        self.summary_label.setText("Scanning in progress...")
        self.duplicate_groups = []
        self.all_groups = []
        self.group_counter = 0
        self.progress.setValue(0)
        
        self.worker = ScanWorker(path, self.ignored_patterns)
        self.worker.progress.connect(self.progress.setValue)
        self.worker.status.connect(self.status_label.setText)
        self.worker.group_found.connect(self.add_group_realtime)
        self.worker.finished.connect(self.scan_finished)
        self.worker.start()

    def stop_scan(self):
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.status_label.setText("Stopping scan...")
            self.stop_btn.setEnabled(False)

    def add_group_realtime(self, group):
        """Add a group to storage and apply filters"""
        self.all_groups.append(group)
        self.apply_filters()

    def apply_filters(self):
        """Apply all filters and rebuild the table"""
        self.table.setRowCount(0)
        self.duplicate_groups = []
        self.group_counter = 0
        
        # Get filter values
        file_type = self.type_combo.currentText()
        min_similarity = self.similarity_spin.value()
        min_size_kb = self.size_spin.value()
        search_text = self.search_box.text().lower()
        
        # Filter groups
        for group in self.all_groups:
            # Similarity filter
            if group['similarity'] < min_similarity:
                continue
            
            # File type filter
            if file_type == "Images Only":
                if not any(f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.webp', '.gif')) 
                          for f in group['files']):
                    continue
            elif file_type == "Text Only":
                if not any(f.lower().endswith(('.txt', '.md', '.py', '.js', '.html', '.css', '.json', '.xml')) 
                          for f in group['files']):
                    continue
            elif file_type == "Other Files":
                if any(f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.webp', '.gif', 
                                          '.txt', '.md', '.py', '.js', '.html', '.css', '.json', '.xml')) 
                      for f in group['files']):
                    continue
            
            # Size filter
            if group['files']:
                try:
                    file_size_kb = os.path.getsize(group['files'][0]) / 1024
                    if file_size_kb < min_size_kb:
                        continue
                except:
                    pass
            
            # Search filter
            if search_text:
                if not any(search_text in f.lower() for f in group['files']):
                    continue
            
            # Add group to display
            self.add_group_to_table(group)
        
        # Update summary
        if self.duplicate_groups:
            total_files = sum(len(g['files']) for g in self.duplicate_groups)
            total_wasted = sum(g['wasted_space'] for g in self.duplicate_groups)
            self.summary_label.setText(
                f"Showing {len(self.duplicate_groups)} of {len(self.all_groups)} groups "
                f"with {total_files} files. Potential space savings: {self.format_size(total_wasted)}"
            )
            self.delete_btn.setEnabled(True)
            self.preview_btn.setEnabled(True)
        else:
            if self.all_groups:
                self.summary_label.setText("No results match current filters")
            else:
                self.summary_label.setText("✓ No duplicate files detected")
            self.delete_btn.setEnabled(False)
            self.preview_btn.setEnabled(False)

    def add_group_to_table(self, group):
        """Add a single group to the table"""
        self.duplicate_groups.append(group)
        group_idx = self.group_counter
        self.group_counter += 1
        
        # Color palette for groups
        if self.dark_mode:
            colors = [
                QColor(180, 100, 100), QColor(100, 180, 100), QColor(100, 100, 180),
                QColor(180, 180, 100), QColor(180, 100, 180), QColor(100, 180, 180),
            ]
        else:
            colors = [
                QColor(255, 200, 200), QColor(200, 255, 200), QColor(200, 200, 255),
                QColor(255, 255, 200), QColor(255, 200, 255), QColor(200, 255, 255),
            ]
        
        color = colors[group_idx % len(colors)]
        group_name = f"Group {group_idx + 1}"
        
        for file_path in group['files']:
            r = self.table.rowCount()
            self.table.insertRow(r)
            
            group_item = QTableWidgetItem(group_name)
            group_item.setData(Qt.UserRole, group_idx)
            group_item.setBackground(color)
            self.table.setItem(r, 0, group_item)
            
            path_item = QTableWidgetItem(file_path)
            path_item.setBackground(color)
            self.table.setItem(r, 1, path_item)
            
            size = os.path.getsize(file_path) if os.path.exists(file_path) else 0
            size_item = QTableWidgetItem(self.format_size(size))
            size_item.setBackground(color)
            self.table.setItem(r, 2, size_item)
            
            sim_item = QTableWidgetItem(f"{group['similarity']:.1f}%")
            sim_item.setBackground(color)
            self.table.setItem(r, 3, sim_item)

    def scan_finished(self, groups):
        """Called when scan completes"""
        self.scan_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        
        if not self.all_groups:
            self.status_label.setText("No duplicates found!")
            self.summary_label.setText("✓ No duplicate files detected")
        else:
            self.status_label.setText(f"Scan complete! Found {len(self.all_groups)} duplicate groups")
    
    def format_size(self, bytes):
        for unit in ['B', 'KB', 'MB', 'GB']:
            if bytes < 1024:
                return f"{bytes:.2f} {unit}"
            bytes /= 1024
        return f"{bytes:.2f} TB"
    
    def open_preview(self, index):
        row = index.row()
        group_idx = self.table.item(row, 0).data(Qt.UserRole)
        self.show_group_preview(group_idx)
    
    def preview_selected_group(self):
        selected = self.table.selectedItems()
        if not selected:
            QMessageBox.warning(self, "No Selection", "Please select a row to preview")
            return
        
        row = selected[0].row()
        group_idx = self.table.item(row, 0).data(Qt.UserRole)
        self.show_group_preview(group_idx)
    
    def show_group_preview(self, group_idx):
        if group_idx >= len(self.duplicate_groups):
            return
        
        group = self.duplicate_groups[group_idx]
        preview = PreviewWindow(group, group_idx + 1, self.dark_mode, self)
        preview.file_deleted.connect(self.refresh_table)
        preview.show()
    
    def refresh_table(self):
        """Refresh table after file deletion"""
        # Filter out groups with deleted files from all_groups
        updated_all_groups = []
        for group in self.all_groups:
            existing_files = [f for f in group['files'] if os.path.exists(f)]
            if len(existing_files) >= 2:
                group['files'] = existing_files
                size = os.path.getsize(existing_files[0]) if existing_files else 0
                group['wasted_space'] = size * (len(existing_files) - 1)
                updated_all_groups.append(group)
        
        self.all_groups = updated_all_groups
        self.apply_filters()
    
    def delete_selected(self):
        selected_rows = set(item.row() for item in self.table.selectedItems())
        
        if not selected_rows:
            QMessageBox.warning(self, "No Selection", "Please select files to delete")
            return
        
        files_to_delete = []
        for row in selected_rows:
            file_path = self.table.item(row, 1).text()
            files_to_delete.append(file_path)
        
        reply = QMessageBox.question(
            self, 
            "Confirm Deletion",
            f"Are you sure you want to delete {len(files_to_delete)} selected file(s)?",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            deleted = 0
            for file_path in files_to_delete:
                try:
                    if os.path.exists(file_path):
                        os.remove(file_path)
                        deleted += 1
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Could not delete {file_path}: {str(e)}")
            
            QMessageBox.information(self, "Success", f"Deleted {deleted} file(s)")
            self.refresh_table()
    
    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.worker.wait()
        event.accept()