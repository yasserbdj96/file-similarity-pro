import os
import hashlib
from difflib import SequenceMatcher

def file_hash(path, quick=False):
    """Calculate file hash. If quick=True, only hash first 8KB for speed"""
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            if quick:
                h.update(f.read(8192))
            else:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
        return h.hexdigest()
    except:
        return None

def quick_hash(path):
    """Fast hash of first 8KB + file size"""
    try:
        size = os.path.getsize(path)
        h = hashlib.sha256()
        with open(path, "rb") as f:
            h.update(f.read(8192))
        return f"{size}_{h.hexdigest()}"
    except:
        return None

def name_similarity(a, b):
    """Compare file names"""
    return 100 if os.path.basename(a).lower() == os.path.basename(b).lower() else 0

def size_similarity(a, b):
    """Compare file sizes"""
    try:
        return 100 if os.path.getsize(a) == os.path.getsize(b) else 0
    except:
        return 0

def text_similarity(a, b):
    """Compare text file contents"""
    try:
        with open(a, "r", errors="ignore") as f1, open(b, "r", errors="ignore") as f2:
            content1 = f1.read(50000)  # Limit to first 50KB for speed
            content2 = f2.read(50000)
            return SequenceMatcher(None, content1, content2).ratio() * 100
    except:
        return None