from PIL import Image
import imagehash
import cv2
import numpy as np

def image_similarity(img1, img2):
    """Compare images using perceptual hashing"""
    try:
        h1 = imagehash.phash(Image.open(img1))
        h2 = imagehash.phash(Image.open(img2))
        diff = h1 - h2
        return max(0, (1 - diff / 64) * 100)
    except:
        return None

def color_similarity(img1, img2):
    """Compare images using color histogram"""
    try:
        i1 = cv2.imread(img1)
        i2 = cv2.imread(img2)
        
        if i1 is None or i2 is None:
            return None
            
        h1 = cv2.calcHist([i1], [0, 1, 2], None, [8, 8, 8], [0, 256] * 3)
        h2 = cv2.calcHist([i2], [0, 1, 2], None, [8, 8, 8], [0, 256] * 3)
        cv2.normalize(h1, h1)
        cv2.normalize(h2, h2)
        return cv2.compareHist(h1, h2, cv2.HISTCMP_CORREL) * 100
    except:
        return None

def quick_image_hash(img_path):
    """Fast image hash for grouping"""
    try:
        return str(imagehash.phash(Image.open(img_path), hash_size=8))
    except:
        return None