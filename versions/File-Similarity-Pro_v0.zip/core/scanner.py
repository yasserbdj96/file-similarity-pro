import os
from collections import defaultdict
from core.file_compare import *
from core.image_compare import *
import fnmatch

IMAGE_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".webp", ".gif")
TEXT_EXT = (".txt", ".md", ".py", ".js", ".html", ".css", ".json", ".xml")

def should_ignore_file(file_path, root_path, ignore_patterns):
    """Check if file should be ignored based on patterns"""
    if not ignore_patterns:
        return False
    
    # Get relative path from root
    try:
        rel_path = os.path.relpath(file_path, root_path)
    except:
        rel_path = file_path
    
    # Normalize path separators
    rel_path = rel_path.replace(os.sep, '/')
    
    for pattern in ignore_patterns:
        pattern = pattern.replace(os.sep, '/')
        
        # Check if pattern matches
        if fnmatch.fnmatch(rel_path, pattern):
            return True
        
        # Check if any parent directory matches
        parts = rel_path.split('/')
        for i in range(len(parts)):
            partial_path = '/'.join(parts[:i+1])
            if fnmatch.fnmatch(partial_path, pattern):
                return True
            if fnmatch.fnmatch(partial_path + '/', pattern):
                return True
    
    return False

def scan_folder(path, should_continue=None, ignore_patterns=None):
    """Recursively scan folder for files with cancellation support and ignore patterns"""
    files = []
    ignore_patterns = ignore_patterns or []
    
    for root, dirs, names in os.walk(path):
        if should_continue and not should_continue():
            break
        
        # Filter out ignored directories
        dirs_to_remove = []
        for d in dirs:
            dir_path = os.path.join(root, d)
            if should_ignore_file(dir_path, path, ignore_patterns):
                dirs_to_remove.append(d)
        
        for d in dirs_to_remove:
            dirs.remove(d)
        
        # Process files
        for n in names:
            if should_continue and not should_continue():
                break
            
            full_path = os.path.join(root, n)
            
            # Check if file should be ignored
            if should_ignore_file(full_path, path, ignore_patterns):
                continue
            
            if os.path.isfile(full_path):
                files.append(full_path)
    
    return files

def find_duplicate_groups(files, progress_callback, status_callback, should_continue=None, result_callback=None):
    """
    Fast duplicate finder using multi-stage approach with cancellation support:
    1. Group by size (instant exact duplicates)
    2. Quick hash for potential duplicates
    3. Full comparison for similar files
    
    result_callback: Called each time a duplicate group is found with the group data
    """
    
    if not files:
        return []
    
    all_groups = []
    
    # Stage 1: Group by size (very fast)
    status_callback("Grouping files by size...")
    size_groups = defaultdict(list)
    for f in files:
        if should_continue and not should_continue():
            return []
        try:
            size = os.path.getsize(f)
            size_groups[size].append(f)
        except:
            continue
    
    # Only keep groups with multiple files
    size_groups = {k: v for k, v in size_groups.items() if len(v) > 1}
    
    if not size_groups:
        return []
    
    # Stage 2: Quick hash within size groups (fast)
    status_callback("Computing quick hashes...")
    hash_groups = defaultdict(list)
    total = sum(len(v) for v in size_groups.values())
    processed = 0
    
    for size, file_list in size_groups.items():
        if should_continue and not should_continue():
            return []
        for f in file_list:
            if should_continue and not should_continue():
                return []
            qh = quick_hash(f)
            if qh:
                hash_groups[qh].append(f)
            processed += 1
            if processed % 10 == 0:
                progress_callback(int((processed / total) * 50))
    
    # Keep groups with 2+ files
    hash_groups = {k: v for k, v in hash_groups.items() if len(v) > 1}
    
    # Stage 3: Full comparison for exact duplicates
    status_callback("Finding exact duplicates...")
    
    for hash_key, file_list in hash_groups.items():
        if should_continue and not should_continue():
            return []
        if len(file_list) < 2:
            continue
            
        # Verify with full hash
        full_hash_groups = defaultdict(list)
        for f in file_list:
            if should_continue and not should_continue():
                return []
            fh = file_hash(f)
            if fh:
                full_hash_groups[fh].append(f)
        
        # Add exact duplicate groups and emit them immediately
        for fh, exact_files in full_hash_groups.items():
            if len(exact_files) >= 2:
                size = os.path.getsize(exact_files[0])
                wasted = size * (len(exact_files) - 1)
                group = {
                    'files': exact_files,
                    'similarity': 100.0,
                    'type': 'exact',
                    'wasted_space': wasted
                }
                all_groups.append(group)
                
                # Emit result immediately if callback provided
                if result_callback:
                    result_callback(group)
    
    progress_callback(75)
    
    # Stage 4: Find similar images
    if should_continue and not should_continue():
        return []
    status_callback("Analyzing similar images...")
    similar_groups = find_similar_images(files, progress_callback, should_continue, result_callback)
    all_groups.extend(similar_groups)
    
    progress_callback(100)
    
    # Sort all groups by wasted space
    all_groups.sort(key=lambda x: x['wasted_space'], reverse=True)
    
    return all_groups

def find_similar_images(files, progress_callback, should_continue=None, result_callback=None):
    """Find similar (but not identical) images with cancellation support"""
    similar_groups = []
    
    # Filter image files
    image_files = [f for f in files if f.lower().endswith(IMAGE_EXT)]
    
    if len(image_files) < 2:
        return []
    
    # Group by image hash (perceptual)
    img_hash_groups = defaultdict(list)
    
    for img in image_files:
        if should_continue and not should_continue():
            return []
        img_hash = quick_image_hash(img)
        if img_hash:
            img_hash_groups[img_hash].append(img)
    
    # Find groups with similar hashes
    processed_hashes = set()
    
    for hash1, files1 in img_hash_groups.items():
        if should_continue and not should_continue():
            return []
        if hash1 in processed_hashes:
            continue
            
        similar_cluster = list(files1)
        
        # Compare with other hash groups
        for hash2, files2 in img_hash_groups.items():
            if should_continue and not should_continue():
                return []
            if hash1 == hash2 or hash2 in processed_hashes:
                continue
            
            # Calculate hash distance
            try:
                h1 = imagehash.hex_to_hash(hash1)
                h2 = imagehash.hex_to_hash(hash2)
                distance = h1 - h2
                
                if distance <= 5:  # Similar images
                    similar_cluster.extend(files2)
                    processed_hashes.add(hash2)
            except:
                continue
        
        # If we found a cluster of similar images
        if len(similar_cluster) >= 2:
            # Calculate average similarity
            similarity = calculate_group_similarity(similar_cluster, should_continue)
            
            if similarity >= 75:  # Only keep if reasonably similar
                try:
                    size = os.path.getsize(similar_cluster[0])
                    wasted = size * (len(similar_cluster) - 1)
                    group = {
                        'files': similar_cluster,
                        'similarity': similarity,
                        'type': 'similar_image',
                        'wasted_space': wasted
                    }
                    similar_groups.append(group)
                    
                    # Emit result immediately if callback provided
                    if result_callback:
                        result_callback(group)
                except:
                    pass
        
        processed_hashes.add(hash1)
    
    return similar_groups

def calculate_group_similarity(files, should_continue=None):
    """Calculate average similarity score for a group with cancellation support"""
    if len(files) < 2:
        return 0
    
    # Sample a few pairs to estimate similarity
    total_sim = 0
    comparisons = 0
    max_comparisons = min(10, len(files) * (len(files) - 1) // 2)
    
    for i in range(min(3, len(files))):
        if should_continue and not should_continue():
            return 0
        for j in range(i + 1, min(i + 4, len(files))):
            if should_continue and not should_continue():
                return 0
            if comparisons >= max_comparisons:
                break
            
            sim = image_similarity(files[i], files[j])
            if sim is not None:
                total_sim += sim
                comparisons += 1
    
    return total_sim / comparisons if comparisons > 0 else 0