from PySide6.QtCore import QThread, Signal
from core.scanner import scan_folder, find_duplicate_groups

class ScanWorker(QThread):
    progress = Signal(int)
    finished = Signal(list)
    status = Signal(str)
    group_found = Signal(dict)

    def __init__(self, path, ignored_patterns=None):
        super().__init__()
        self.path = path
        self.ignored_patterns = ignored_patterns or []
        self._is_running = True

    def stop(self):
        """Stop the scanning process"""
        self._is_running = False

    def is_running(self):
        """Check if worker should continue running"""
        return self._is_running

    def run(self):
        self.status.emit("Scanning files...")
        files = scan_folder(self.path, lambda: self._is_running, self.ignored_patterns)
        
        if not self._is_running:
            self.status.emit("Scan cancelled")
            self.finished.emit([])
            return
        
        self.status.emit(f"Found {len(files)} files. Analyzing duplicates...")
        
        results = find_duplicate_groups(
            files, 
            self.progress.emit, 
            self.status.emit, 
            lambda: self._is_running,
            self.emit_group
        )
        
        if not self._is_running:
            self.status.emit("Scan cancelled")
            self.finished.emit([])
        else:
            self.finished.emit(results)
    
    def emit_group(self, group):
        """Emit a newly found group immediately"""
        self.group_found.emit(group)